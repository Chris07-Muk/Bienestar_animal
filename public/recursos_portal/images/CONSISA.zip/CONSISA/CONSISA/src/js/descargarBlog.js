// Evitar el comportamiento por defecto del formulario
document.getElementById('blogForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Recoger los valores del formulario
    const title = document.getElementById('title').value;
    const subtitle = document.getElementById('subtitle').value;
    const category = document.getElementById('category').value;
    const author = document.getElementById('author').value;
    const date = document.getElementById('date').value;
    const content = document.getElementById('content').value;

    // Crear el contenido para el archivo de texto
    const blogData = `Título: ${title}\nSubtítulo: ${subtitle}\nCategoría: ${category}\nAutor: ${author}\nFecha: ${date}\nContenido:\n${content}\n\n`;

    // Crear un enlace para descargar el archivo
    const blob = new Blob([blogData], { type: 'text/plain' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'entrada_blog.txt';  // Nombre del archivo
    link.click();

    // Limpiar el formulario
    document.getElementById('blogForm').reset();
});