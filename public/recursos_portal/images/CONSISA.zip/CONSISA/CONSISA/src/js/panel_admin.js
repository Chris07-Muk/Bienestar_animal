const logoutButton = document.getElementById("logoutButton");
    const addBlogButton = document.getElementById("addBlogButton");
    const blogTableBody = document.getElementById("blogTableBody");

    // Redirección al login
    if (logoutButton) {
      logoutButton.addEventListener("click", () => {
        window.location.href = "login_admin_blogs.html";
      });
    }

    // Redirección al formulario de agregar blogs
    if (addBlogButton) {
      addBlogButton.addEventListener("click", () => {
        window.location.href = "crear_blogs.html";
      });
    }

    // Función para cargar los blogs desde el servidor
    function loadBlogs() {
      fetch("get_blogs.php")
        .then((response) => response.json())
        .then((blogs) => {
          blogTableBody.innerHTML = ""; // Limpiar tabla
          blogs.forEach((blog, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `
              <td>${index + 1}</td>
              <td>${blog.title}</td>
              <td>${blog.views}</td>
              <td>${blog.date}</td>
              <td>
                <button class="delete-button" data-file="${blog.file}">Eliminar</button>
              </td>
            `;
            blogTableBody.appendChild(row);
          });

          // Agregar eventos de eliminar
          document.querySelectorAll(".delete-button").forEach((button) => {
            button.addEventListener("click", (e) => {
              const file = e.target.dataset.file;
              deleteBlog(file);
            });
          });
        })
        .catch((error) => {
          console.error("Error al cargar los blogs:", error);
        });
    }

    // Función para eliminar un blog
    function deleteBlog(file) {
      if (confirm("¿Estás seguro de que deseas eliminar este blog?")) {
        fetch("delete_blog.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ file }),
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              alert("Blog eliminado correctamente.");
              loadBlogs(); // Recargar la lista
            } else {
              alert("Error al eliminar el blog.");
            }
          })
          .catch((error) => {
            console.error("Error al eliminar el blog:", error);
          });
      }
    }

    // Cargar blogs al inicio
    loadBlogs();