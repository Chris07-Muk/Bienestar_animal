// Capturar el evento submit en el formulario
document.getElementById("loginForm").addEventListener("submit", function (event) {
    // Prevenir que el formulario se envíe de manera convencional
    event.preventDefault();
  
    // Obtener valores de los campos
    const email = document.querySelector('input[name="mail"]').value;
    const password = document.querySelector('input[name="pass"]').value;
  
    // Credenciales válidas
    const validEmail = "admin@consisa.com";
    const validPassword = "admin";
  
    // Verificar credenciales
    if (email === validEmail && password === validPassword) {
      // Redirigir a admin_blogs.html si las credenciales son correctas
      window.location.href = "panel_administrar_blogs.html"; // Redirige al archivo admin_blogs.html en la misma carpeta
    } else {
      // Mostrar alerta si las credenciales son incorrectas
      alert("Credenciales incorrectas. Por favor, inténtelo de nuevo.");
    }
  });
  