<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blogs</title>
    <link rel="stylesheet" href="../css/estilo_index_blogs.css">
</head>
<body>
    <div class="header">
        <svg xmlns="http://www.w3.org/2000/svg" height="40" id="Menu" viewBox="0 -960 960 960" width="40"><path d="M120-240v-66.666h720V-240H120Zm0-206.667v-66.666h720v66.666H120Zm0-206.667V-720h720v66.666H120Z"/></svg>
        
        <!-- Enlace al logo -->
        <a href="../../../index.html">
            <img src="../css/imagenes/LogoConsisa.png" alt="logotipo" id="index">
        </a>
        <div class="Enlaces">
            <ul>                
                <li><a href="../../../index.html#Servicio" id="Servicios">Servicios</a></li>
                <li><a href="../html/sobreNosotros.html">Nosotros</a></li>
                <li><a href="../../../index.html#Contactenos">Contactenos</a></li>
            </ul>
        </div>
    </div>
    <section class="blog-container">
    <?php
    // Directorio donde están los blogs
    $blogDir = "../blogs/";

    // Lista de archivos en el directorio
    $files = array_diff(scandir($blogDir), ['.', '..']);

    // Iterar sobre los archivos y generar las tarjetas
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
            $filePath = $blogDir . $file;
            $lines = file($filePath, FILE_IGNORE_NEW_LINES);

            // Variables para almacenar los datos del blog
            $title = $subtitle = $category = $author = $date = $content = $image = "";

            // Leer los datos del archivo línea por línea
            foreach ($lines as $line) {
                if (str_starts_with($line, "Título: ")) {
                    $title = substr($line, 8);
                } elseif (str_starts_with($line, "Subtítulo: ")) {
                    $subtitle = substr($line, 11);
                } elseif (str_starts_with($line, "Categoría: ")) {
                    $category = substr($line, 11);
                } elseif (str_starts_with($line, "Autor: ")) {
                    $author = substr($line, 7);
                } elseif (str_starts_with($line, "Fecha: ")) {
                    $date = substr($line, 7);
                } elseif (str_starts_with($line, "Contenido: ")) {
                    $content = substr($line, 11);
                } elseif (str_starts_with($line, "Imagen: ")) {
                    $image = substr($line, 8);
                }
            }

            // Generar la tarjeta para el blog con enlace dinámico
            echo "
            <div class='blog-item'>
                <img src='$image' alt='Imagen del blog'>
                <h2>$title</h2>
                <p class='excerpt'>$subtitle</p>
                <!-- Enlace con el nombre del archivo como parámetro en la URL -->
                <a href='./blogs.php?blog=$file'>Leer más</a>
            </div>
            ";
        }
    }
    ?>
</section>
    <footer>
        <p>&copy; 2024 CONSISA</p>
    </footer>
</body>
</html>

















