<?php
// Ruta de la carpeta de blogs
$blogDir = '../blogs';

// Verificar si la carpeta de blogs existe
if (!is_dir($blogDir)) {
    die("Error: La carpeta de blogs no existe.");
}

// Obtener la lista de archivos .txt
$files = array_filter(scandir($blogDir), function ($file) use ($blogDir) {
    return pathinfo("$blogDir/$file", PATHINFO_EXTENSION) === 'txt';
});

// Función para extraer datos del blog
function getBlogData($filePath) {
    $content = file_get_contents($filePath);
    $lines = explode("\n", $content);
    return [
        "title" => $lines[0] ?? "Sin título",
        "date" => date("Y-m-d", filemtime($filePath)),
    ];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="../css/estilo_panel_administrar_blogs.css">
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <div class="user-profile">
                <div class="user-photo">
                    <img src="../css/imagenes/Usuario.png" alt="Foto de Admin">
                </div>
                <h3>Administrador Consisa</h3>
            </div>
            <nav class="menu">
                <ul>
                    <li><a href="../html/login_admin_blogs.html">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <header class="header">
                <a href="../html/crear_blogs.html" class="add-button">Agregar Blog</a>
            </header>
            <section class="blog-list">
                <h2>Blogs</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Título</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($files as $file) {
                            $filePath = "$blogDir/$file";
                            $blogData = getBlogData($filePath);
                            $id = pathinfo($file, PATHINFO_FILENAME);

                            // Verificar si existe una imagen asociada (.jpg o .png)
                            $imageExtensions = ['jpg', 'png'];
                            $imageFile = null;
                            foreach ($imageExtensions as $ext) {
                                if (file_exists("$blogDir/$id.$ext")) {
                                    $imageFile = "$id.$ext";
                                    break;
                                }
                            }

                            echo "<tr>";
                            echo "<td>$id</td>";
                            echo "<td>{$blogData['title']}</td>";
                            echo "<td>{$blogData['date']}</td>";
                            echo "<td>
                                    <form method='POST' action='./eliminar_blogs.php' style='display:inline;'>
                                        <input type='hidden' name='file' value='$file'>
                                        <input type='hidden' name='image' value='$imageFile'>
                                        <button type='submit' class='delete-button'>Eliminar</button>
                                    </form>
                                  </td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>
</body>
</html>
