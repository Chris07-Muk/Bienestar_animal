<?php
// Ruta de la carpeta de blogs
$blogDir = '../blogs';

// Verificar si se recibió el archivo
if (!isset($_POST['file'])) {
    die("Error: No se especificó el archivo a eliminar.");
}

$file = basename($_POST['file']); // Sanitizar la entrada
$filePath = "$blogDir/$file";

// Eliminar el archivo .txt
if (file_exists($filePath)) {
    unlink($filePath);
} else {
    echo "<script>alert('El archivo del blog no existe.');</script>";
}

// Verificar si se recibió una imagen y eliminarla
if (isset($_POST['image']) && !empty($_POST['image'])) {
    $image = basename($_POST['image']); // Sanitizar la entrada
    $imagePath = "$blogDir/$image";

    if (file_exists($imagePath)) {
        unlink($imagePath);
    }
}

echo "<script>alert('Blog eliminado correctamente.'); window.location.href='./panel_administrar_blogs.php';</script>";
?>
