<?php
// Ruta donde se encuentran los blogs guardados
$blogDir = "../blogs/";

// Verificamos si hay archivos en la carpeta
$blogs = array_diff(scandir($blogDir), array('..', '.'));

// Filtrar solo los archivos .txt
$txtFiles = array_filter($blogs, function($file) {
    return pathinfo($file, PATHINFO_EXTENSION) === 'txt';
});

// Arreglo para almacenar los blogs
$blogData = [];

// Leer cada archivo de blog y extraer los datos
foreach ($txtFiles as $file) {
    // Leer el contenido del archivo
    $content = file_get_contents($blogDir . $file);
    
    // Extraer los datos del blog con expresiones regulares
    preg_match("/Título: (.+)/", $content, $titleMatch);
    preg_match("/Subtítulo: (.+)/", $content, $subtitleMatch);
    preg_match("/Categoría: (.+)/", $content, $categoryMatch);
    preg_match("/Autor: (.+)/", $content, $authorMatch);
    preg_match("/Fecha: (.+)/", $content, $dateMatch);
    preg_match("/Imagen: (.+)/", $content, $imageMatch);

    $blogData[] = [
        'title' => $titleMatch[1] ?? "Título no disponible",
        'subtitle' => $subtitleMatch[1] ?? "Subtítulo no disponible",
        'category' => $categoryMatch[1] ?? "Categoría no disponible",
        'author' => $authorMatch[1] ?? "Autor no disponible",
        'date' => $dateMatch[1] ?? "Fecha no disponible",
        'image' => $imageMatch[1] ?? 'default_image.jpg',  // Imagen por defecto si no se encuentra
        'file' => $file
    ];
}

// Incluimos el archivo HTML de la plantilla
include('../html/index_blog.html');
?>
