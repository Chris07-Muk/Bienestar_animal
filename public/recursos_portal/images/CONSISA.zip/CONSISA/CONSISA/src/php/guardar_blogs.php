<?php
// Verifica si el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recopila los datos del formulario
    $title = htmlspecialchars($_POST['title']);
    $subtitle = htmlspecialchars($_POST['subtitle']);
    $category = htmlspecialchars($_POST['category']);
    $author = htmlspecialchars($_POST['author']);
    $date = htmlspecialchars($_POST['date']);
    $content = htmlspecialchars($_POST['content']);

    // Ruta donde se guardarán los archivos de texto y las imágenes
    $blogDir = "../blogs/";
    $imageDir = "../blogs/";

    // Crea los directorios si no existen
    if (!is_dir($blogDir)) {
        mkdir($blogDir, 0777, true);
    }
    if (!is_dir($imageDir)) {
        mkdir($imageDir, 0777, true);
    }

    // Procesa la imagen si fue subida
    $imagePath = "";
    if (!empty($_FILES['image']['name'])) {
        $imageName = basename($_FILES['image']['name']);
        $imagePath = $imageDir . $imageName;
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
            die("Error al guardar la imagen.");
        }
    }

    // Genera el contenido del archivo .txt
    $blogContent = "Título: $title\n";
    $blogContent .= "Subtítulo: $subtitle\n";
    $blogContent .= "Categoría: $category\n";
    $blogContent .= "Autor: $author\n";
    $blogContent .= "Fecha: $date\n";
    $blogContent .= "Contenido: \n$content\n";
    $blogContent .= $imagePath ? "Imagen: $imagePath\n" : "Imagen: Ninguna\n";

    // Genera un nombre único para el archivo de texto
    $filename = $blogDir . uniqid("blog_", true) . ".txt";

    // Guarda el contenido en el archivo de texto
    if (file_put_contents($filename, $blogContent) === false) {
        die("Error al guardar el archivo del blog.");
    }

    // Mensaje de éxito
    echo '
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Administrar Blogs</title>
            <!-- Enlace al archivo CSS para los estilos -->
            <link rel="stylesheet" href="../css/estilo_crear_blogs.css">
            </head>
        <body>
            <header>
                <div class="logo">
                    <!-- Enlace al inicio de la página -->
                    <a href="../../../index.html">
                    <img src="../css/imagenes/LogoConsisa.png" alt="logotipo" id="index" style="height: 50px;">
                    </a>
                </div>
                <nav>
                    <!-- Enlace al panel de administración -->
                    <a href="./panel_administrar_blogs.php">Menú</a>
                </nav>
            </header>

            <div class="mensaje">
                <h2>¡Acción completada exitosamente!</h2>
                <p>Tu blog se ha guardado correctamente. Haz clic en "Menú" en la parte superior para volver al panel de control o haz clic <a href="./panel_administrar_blogs.php">aquí...</a></p>
            </div>
            <footer>
                <p>&copy; 2024 Blog</p>
            </footer>
        </body>
        </html>

    ';
} else {
    echo "No se recibió ningún dato.";
}
?>
