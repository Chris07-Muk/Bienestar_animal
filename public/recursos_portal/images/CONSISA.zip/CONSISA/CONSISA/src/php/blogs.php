<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blogs</title>
    <link rel="stylesheet" href="../css/estilo_index_blogs.css">
</head>
<body>
    <div class="header">
        <svg xmlns="http://www.w3.org/2000/svg" height="40" id="Menu" viewBox="0 -960 960 960" width="40"><path d="M120-240v-66.666h720V-240H120Zm0-206.667v-66.666h720v66.666H120Zm0-206.667V-720h720v66.666H120Z"/></svg>
        
        <!-- Enlace al logo -->
        <a href="../../../index.html">
            <img src="../css/imagenes/LogoConsisa.png" alt="logotipo" id="index">
        </a>
        <div class="Enlaces">
            <ul>                
                <li><a href="../../../index.html#Servicio" id="Servicios">Servicios</a></li>
                <li><a href="../html/sobreNosotros.html">Nosotros</a></li>
                <li><a href="../../../index.html#Contactenos">Contactenos</a></li>
            </ul>
        </div>
    </div>

    <section class="blog-container">
    <?php
    // Obtener el parámetro 'blog' de la URL
    if (isset($_GET['blog'])) {
        // Obtener el nombre del archivo desde la URL
        $blogFile = $_GET['blog'];

        // Directorio donde están los blogs
        $blogDir = "../blogs/";

        // Verificar si el archivo existe
        $filePath = $blogDir . $blogFile;
        if (file_exists($filePath)) {
            $lines = file($filePath, FILE_IGNORE_NEW_LINES);

            // Variables para almacenar los datos del blog
            $title = $subtitle = $category = $author = $date = $content = $image = "";
            $contentStarted = false;

            // Leer los datos del archivo línea por línea
            foreach ($lines as $line) {
                if (str_starts_with($line, "Título: ")) {
                    $title = substr($line, 8);
                } elseif (str_starts_with($line, "Subtítulo: ")) {
                    $subtitle = substr($line, 11);
                } elseif (str_starts_with($line, "Categoría: ")) {
                    $category = substr($line, 11);
                } elseif (str_starts_with($line, "Autor: ")) {
                    $author = substr($line, 7);
                } elseif (str_starts_with($line, "Fecha: ")) {
                    $date = substr($line, 7);
                } elseif (str_starts_with($line, "Imagen: ")) {
                    $image = substr($line, 8);
                } elseif (str_starts_with($line, "Contenido: ")) {
                    $contentStarted = true;
                    $content = substr($line, 11); // Iniciar contenido
                } elseif ($contentStarted) {
                    $content .= "\n" . $line; // Concatenar todo el contenido
                }
            }

            // Usar nl2br para convertir los saltos de línea en etiquetas <br>
            $content = nl2br($content);

            // Mostrar el contenido del blog
            echo "<div class='blog-item'>";
            echo "<img src='$image' alt='Imagen del blog'>";
            echo "<h2>$title</h2>";
            echo "<p class='author'>$author - $date</p>";
            echo "<p class='category'>$category</p>";
            echo "<p class='content'>$content</p>";
            echo "</div>";
        } else {
            echo "<p>Blog no encontrado.</p>";
        }
    } else {
        echo "<p>No se ha especificado un blog.</p>";
    }
    ?>
    </section>

    <footer>
        <p>&copy; 2024 CONSISA</p>
    </footer>
</body>
</html>
